export function detectPageContext() {
  const path = window.location.pathname;

  return {
    url: window.location.href,
    path,
    isCoursePage: path.startsWith("/learn/"),
    isQuizPage: /quiz|exam|assignment/i.test(path),
    isPeerReviewPage: /peer/i.test(path),
  };
}

