const PANEL_ID = "coursera-tool-reconstructed-panel";

export function mountDeveloperPanel({ settings, pageContext }) {
  if (document.getElementById(PANEL_ID)) return;

  const panel = document.createElement("aside");
  panel.id = PANEL_ID;
  panel.style.cssText = [
    "position:fixed",
    "right:16px",
    "bottom:16px",
    "z-index:2147483647",
    "width:300px",
    "padding:16px",
    "border:1px solid #ccd5e0",
    "border-radius:10px",
    "background:#fff",
    "color:#17233c",
    "box-shadow:0 8px 30px rgba(0,0,0,.16)",
    "font:14px/1.45 system-ui,sans-serif",
  ].join(";");

  panel.innerHTML = `
    <strong>Coursera Tool — Dev</strong>
    <p style="margin:8px 0">Clean reconstruction is active.</p>
    <dl style="margin:0">
      <dt>Page</dt><dd style="margin:0 0 6px">${escapeHtml(pageContext.path)}</dd>
      <dt>Automation</dt><dd style="margin:0">${settings.automationEnabled ? "enabled" : "disabled"}</dd>
    </dl>
    <button type="button" style="margin-top:12px">Close</button>
  `;

  panel.querySelector("button").addEventListener("click", () => panel.remove());
  document.documentElement.append(panel);
}

function escapeHtml(value) {
  const node = document.createElement("span");
  node.textContent = String(value);
  return node.innerHTML;
}

