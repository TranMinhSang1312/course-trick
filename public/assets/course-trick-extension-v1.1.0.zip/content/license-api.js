export const API = "https://course-trick.sang13122005.workers.dev";
async function request(path, options = {}) {
  const response = await fetch(`${API}${path}`, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(translate(data.error, response.status));
    error.code = data.code;
    error.status = response.status;
    throw error;
  }
  return data;
}
export const createOrder = (buyerEmail) => request("/v1/orders", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ buyerEmail }) });
export const getOrder = (orderCode) => request(`/v1/orders/${encodeURIComponent(orderCode)}`);
export const activateLicense = (licenseKey, installationId, courseraEmail) => request("/v1/licenses/activate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ licenseKey, installationId, courseraEmail }) });
export const refreshLicense = (refreshToken, installationId, courseraEmail) => request("/v1/licenses/refresh", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ refreshToken, installationId, courseraEmail }) });
export const getEntitlement = (accessToken, courseraEmail) => request("/v1/entitlements/me", { headers: { Authorization: `Bearer ${accessToken}`, "X-Coursera-Email": courseraEmail } });
export const recoverLicense = (courseraEmail, installationId) => request("/v1/licenses/recover", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ courseraEmail, installationId }) });
function translate(error, status) {
  return ({ "Invalid license": "Gói Premium chưa được kích hoạt hoặc đã hết hạn.", "Invalid or expired license": "Gói Premium không hợp lệ hoặc đã hết hạn.", "License expired": "Gói Premium đã hết hạn.", "An active license already exists": "Email này đã có Premium còn hạn. Hãy khôi phục thay vì thanh toán lại.", "Please wait before creating another order": "Hãy chờ một phút trước khi tạo đơn mới.", "Please wait before moving Premium to another device": "Hãy chờ một phút trước khi chuyển Premium sang thiết bị khác.", "Use account recovery for this installation": "Hãy dùng chức năng khôi phục Premium trên thiết bị này.", "Coursera account does not match this purchase": "Tài khoản Coursera không khớp email đã mua.", "Coursera account does not match this license": "Tài khoản Coursera không khớp license.", "No active license for this Coursera account": "Tài khoản Coursera này chưa có Premium còn hạn.", "Unable to create payment": "Không thể tạo thanh toán payOS. Hãy thử lại.", Unauthorized: "Phiên Premium đã hết hạn." })[error] || error || `Máy chủ trả về lỗi ${status}.`;
}
