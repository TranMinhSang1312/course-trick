(async () => {
  const moduleUrl = chrome.runtime.getURL("content/index.js");
  const { startExtension } = await import(moduleUrl);
  await startExtension();
})().catch((error) => console.error("[Coursera Tool Dev] startup failed", error));

