export const STORAGE_KEY = "courseTrickLicense";

export async function getLicenseState() {
  const data = await chrome.storage.local.get(STORAGE_KEY);
  return data[STORAGE_KEY] ?? {};
}
export async function saveLicenseState(patch) {
  const next = { ...(await getLicenseState()), ...patch };
  await chrome.storage.local.set({ [STORAGE_KEY]: next });
  return next;
}
export async function getInstallationId() {
  const state = await getLicenseState();
  if (state.installationId) return state.installationId;
  const installationId = crypto.randomUUID();
  await saveLicenseState({ installationId });
  return installationId;
}
